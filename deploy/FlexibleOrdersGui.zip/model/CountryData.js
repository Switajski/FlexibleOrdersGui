Ext.define('MyApp.model.CountryData', {
    extend: 'Ext.data.Model',

    idProperty: 'id',

    fields: [{
        name: 'country'
    }]
});