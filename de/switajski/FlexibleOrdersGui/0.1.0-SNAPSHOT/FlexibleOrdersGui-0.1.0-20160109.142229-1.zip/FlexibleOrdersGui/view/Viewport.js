Ext.define('MyApp.view.Viewport', {
    extend: 'MyApp.view.MainPanel',
    renderTo: Ext.getBody()
});